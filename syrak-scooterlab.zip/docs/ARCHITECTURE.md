# Syrak ScooterLab — Architecture & Engineering Charter

A production-grade Android platform for multi-brand electric-scooter diagnostics,
RAM tuning and firmware management. This document is the single source of truth
for the system's structure, the rationale behind each layer, and the build roadmap.

---

## 1. Design Doctrine

The product must never look like a hobby project. The rules are non-negotiable:

- **No emojis, ever.** Iconography is custom vector drawables only.
- **Material 3, dark-only.** A diagnostic tool lives in the dark; there is no light mode.
- **Strict 4pt spatial grid.** Every dimension is a multiple of 4 (`SyrakSpacing`).
- **Monospace for data.** Telemetry digits never jitter — readouts use a monospace face.
- **Restrained radii.** Corners are sharp (6–18dp), never bubbly.
- **Semantic colour.** Crimson = danger/action, acid green = nominal, cyan = data, amber = warning.

### Palette

| Token | Hex | Role |
|-------|-----|------|
| `SyrakBlack` | `#0C0C12` | App background (matte black) |
| `SyrakSlate` | `#161A22` | Base surface |
| `SyrakSlateElevated` | `#1E232E` | Cards |
| `SyrakOutline` | `#2A3140` | Hairlines |
| `Crimson` | `#FF3C3C` | Primary / danger |
| `Acid` | `#00E676` | Success / nominal |
| `Cyan` | `#00E5FF` | Data readouts |
| `Amber` | `#FFB020` | Warning |

The palette lives in **two places that must stay in sync**: `res/values/colors.xml`
(XML/vector consumers) and `ui/theme/Color.kt` (Compose). A future Gradle task can
generate one from the other.

---

## 2. Module Map

```
com.syrak.scooterlab
├── SyrakApp                     Application; owns AppContainer
├── MainActivity                 Compose host + runtime permission gate
├── di/AppContainer              Explicit, framework-free DI graph
├── core/
│   ├── ble/
│   │   ├── BleConstants         UUIDs, MTU, timeouts, scan filters
│   │   ├── BleModels            DiscoveredScooter, ConnectionState, GattEvent
│   │   ├── BlePermissions       SDK-aware permission matrix
│   │   ├── BleManager           Scan + GATT lifecycle + serialized write pump
│   │   └── BleSessionService    Foreground service for long operations
│   ├── protocol/
│   │   ├── Crc16                CRC-16/XMODEM
│   │   ├── NinebotFrame         Frame encode/decode + validation
│   │   ├── NinebotProtocol      Addressing, commands, frame factory
│   │   ├── RegisterMap          Documented, verifiable register constants
│   │   ├── NinebotAuth          AES-128-ECB challenge/response scaffold
│   │   └── NinebotSession       Request/response correlator
│   └── util/Hex                 Hex codec for the console
├── feature/
│   ├── tuning/GermanManeuver    Volatile RAM patch + revert
│   ├── telemetry/               Telemetry model, poller, simulator
│   └── safety/KillSwitch        Emergency containment
├── data/ScooterRepository       Facade composing transport + features
└── ui/
    ├── theme/                   Colour, type, spacing, shape, theme engine
    ├── components/              NeonCard, GaugeRing, StatTile, StatusChip…
    └── dashboard/               ViewModel + screen
```

**Dependency rule:** `ui → data → feature → core`. Nothing in `core` knows about
`ui` or Android UI types. `BleManager` is the only class that touches `BluetoothGatt`.

---

## 3. BLE Transport (`BleManager`)

### 3.1 Discovery

Scanning uses **service-UUID filters** (`6e400001…` UART, `0000fe95…` Xiaomi) with
`SCAN_MODE_LOW_LATENCY`. A fallback "brand sweep" (no filter) is available; results
are then classified by advertised-name prefix via `ScooterBrand.classify`.

### 3.2 Connection handshake

```
connectGatt(TRANSPORT_LE, PHY_LE_1M, mainHandler)
   └─ onConnectionStateChange(CONNECTED)
        └─ discoverServices()
             └─ onServicesDiscovered → locate WRITE + NOTIFY chars
                  └─ setCharacteristicNotification + write CCCD
                       └─ onDescriptorWrite → requestMtu(247)
                            └─ onMtuChanged → state = Ready
```

Every stage completes a `CompletableDeferred`; the whole handshake is wrapped in a
12-second timeout. Any `GATT_SUCCESS` deviation fails the deferred with a reason and
tears the link down. **No stage can silently hang.**

### 3.3 The write pump

BLE permits exactly one outstanding GATT operation. `BleManager` therefore owns a
`Channel<ByteArray>` consumed by a single coroutine. Each logical frame is split to
`MTU − 3` and written sequentially, awaiting `onCharacteristicWrite` before the next
chunk, with bounded retries. This eliminates the classic "write dropped under load"
bug that plagues naive BLE code.

### 3.4 Threading

GATT callbacks are pinned to the **main looper** (`Handler(Looper.getMainLooper())`)
for deterministic ordering. The write pump runs on the application scope
(`Dispatchers.Default`). All public methods are safe from any dispatcher.

---

## 4. Protocol Layer

### 4.1 Frame format

```
┌──────┬──────┬──────┬──────┬──────┬──────┬───────────┬─────────┐
│ 0x5A │ 0xA5 │ LEN  │ SRC  │ DST  │ CMD  │  PAYLOAD  │  CRC16  │
└──────┴──────┴──────┴──────┴──────┴──────┴───────────┴─────────┘
LEN = 3 + payload.size      CRC16 little-endian over [LEN .. payload]
```

- **Nodes:** `0x20` ESC · `0x21` BLE · `0x22` BMS · `0x3D` APP
- **Commands:** `0x01` READ · `0x02` WRITE
- **CRC:** CRC-16/CCITT (XMODEM), poly `0x1021`, init `0x0000`. Verified against the
  canonical check value `0x31C3` for `"123456789"` in `NinebotFrameTest`.

### 4.2 Correlation

`NinebotSession` demultiplexes the single inbound stream by `(source, command)` using
a small replay buffer to close the subscribe/write race. `readRegister()` is the
ergonomic entry point; it returns raw value bytes or `null` on timeout (never throws).

### 4.3 ⚠️ Register map is firmware-specific

`RegisterMap` is a **reference scaffold**. Real addresses differ across ESC firmware
revisions and brands. Before any write on real hardware you must:

1. Dump the target controller's registers via the Diagnostics console.
2. Correlate addresses against a known-good firmware image.
3. Update `RegisterMap` and its `WRITABLE` allow-list.

`GermanManeuver` and `KillSwitch` refuse to write any register not in `WRITABLE`.

---

## 5. The German Maneuver

A **volatile** RAM patch that raises the speed ceiling by rewriting the region and
speed-limit registers in the ESC's working memory.

- **Non-persistent** — reverts on the next power cycle.
- **Reversible** — baseline values are captured first and restorable in one tap.
- **Guarded** — only `WRITABLE` registers are touched; read-back verification confirms
  the write landed.

```
read baseline (region, speed) → write region=GLOBAL → write speed=target → read-back verify
```

> **Legal & safety notice.** Raising the speed limit above the factory regional cap is
> illegal on public roads in many jurisdictions (including Germany) and voids the
> vehicle's type approval. This feature is provided for closed-course and diagnostic
> use. The UI must surface this notice before applying.

---

## 6. Safety Model

The `KillSwitch` is defence-in-depth, not a substitute for the physical brake:

1. Cruise control OFF — remove any latched throttle.
2. Speed limit → 0 — the firmware refuses to command motion.
3. Internal latch — further throttle commands are blocked locally.

It is idempotent, and the UI presents it as *electronic containment for bench use*.

---

## 7. Telemetry

`NinebotTelemetrySource` polls ESC + BMS registers on a fixed cadence and decodes
them into a normalised `Telemetry` model. Derived signals:

- `powerW = voltageV × currentA`
- `cellDeltaMv = (cellMax − cellMin) × 1000` → pack balance / health heuristic
- `estimatedRangeKm` from state-of-charge against a nominal range

A `SimulatedTelemetrySource` drives the dashboard before hardware is attached; the UI
shows a **SIM** badge whenever synthetic data is in use. Real hardware always wins.

---

## 8. Build & Run

```bash
# Requirements: JDK 17, Android SDK 35
./gradlew :app:assembleDebug      # build the debug APK
./gradlew :app:testDebugUnitTest  # run protocol unit tests
```

The project targets `minSdk 26`, `targetSdk 35`, Kotlin 2.0, Compose BOM 2024.10.

---

## 9. Roadmap

### Phase 1 — Foundation ✅ (this drop)
Design system, BLE transport, protocol engine, German Maneuver, telemetry, killswitch,
dashboard.

### Phase 2 — Diagnostics & Firmware
- Register inspector / hex console screen with live read-write.
- Firmware manager: fetch, verify (signature + CRC), and flash ESC/BLE/BMS over the
  existing GATT link with resumable chunked DFU.
- Per-model register profiles (`ScooterProfile`) selected by model + firmware version.

### Phase 3 — Depth
- Multi-brand adapters (Xiaomi `fe95` handshake, Navee command set) behind a
  `ScooterProtocol` interface.
- Session recording + replay (CSV/JSON) for field diagnostics.
- Battery health analytics (per-cell history, degradation curve).

### Phase 4 — Polish & Hardening
- Foreground-service–backed persistent sessions.
- Crash-free-rate instrumentation, structured logging, remote config for register maps.
- Accessibility pass (TalkBack labels, dynamic type, contrast audit).
- CI: unit tests, lint, R8 verification, baseline profiles.

---

## 10. Engineering Standards Checklist

- [x] No emojis anywhere in the UI.
- [x] Compose UI built from a reusable, tokenised component library.
- [x] Exhaustive `ConnectionState` / `GattEvent` sealed hierarchies — no silent states.
- [x] All BLE operations timeout-bounded; no unbounded waits.
- [x] Serialized, MTU-aware, retrying write pump.
- [x] Runtime permission matrix handled centrally.
- [x] Safety-critical writes gated behind an allow-list + verification.
- [x] Protocol logic pure and unit-tested.
- [x] Framework-free DI so the graph is defined in one place.
