package com.syrak.scooterlab.core.protocol

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class NinebotFrameTest {

    @Test
    fun crc16XmodemMatchesCanonicalVector() {
        // CRC-16/XMODEM check value for "123456789" is 0x31C3.
        val data = "123456789".toByteArray(Charsets.US_ASCII)
        assertEquals(0x31C3, Crc16.xmodem(data))
    }

    @Test
    fun frameSurvivesEncodeDecodeRoundTrip() {
        val frame = NinebotProtocol.buildWriteByte(NinebotProtocol.ADDR_ESC, RegisterMap.SPEED_LIMIT, 0x1E)
        val decoded = NinebotFrame.decode(frame.encode())
        assertNotNull(decoded)
        assertEquals(frame, decoded)
    }

    @Test
    fun decodeRejectsCorruptedChecksum() {
        val encoded = NinebotProtocol.buildRead(NinebotProtocol.ADDR_ESC, RegisterMap.SPEED).encode()
        encoded[encoded.lastIndex] = (encoded[encoded.lastIndex] + 1).toByte()
        assertNull(NinebotFrame.decode(encoded))
    }

    @Test
    fun decodeRejectsTruncatedInput() {
        assertNull(NinebotFrame.decode(byteArrayOf(0x5A, 0xA5, 0x01)))
    }

    @Test
    fun littleEndianDecodersAreCorrect() {
        val bytes = byteArrayOf(0x34, 0x12, 0x78, 0x56)
        assertEquals(0x1234, NinebotProtocol.u16LE(bytes))
        assertEquals(0x56781234L, NinebotProtocol.u32LE(bytes))
    }
}
