package com.syrak.scooterlab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.syrak.scooterlab.core.ble.BlePermissions
import com.syrak.scooterlab.ui.dashboard.DashboardRoute
import com.syrak.scooterlab.ui.dashboard.DashboardViewModel
import com.syrak.scooterlab.ui.theme.SyrakBlack
import com.syrak.scooterlab.ui.theme.SyrakTheme
import timber.log.Timber

class MainActivity : ComponentActivity() {

    private val viewModel: DashboardViewModel by viewModels {
        DashboardViewModel.factory((application as SyrakApp).container.repository)
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val denied = grants.filterValues { granted -> !granted }.keys
            if (denied.isEmpty()) {
                Timber.i("BLE permissions granted")
            } else {
                Timber.w("BLE permissions denied: %s", denied.joinToString())
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SyrakTheme {
                Surface(color = SyrakBlack, modifier = Modifier.fillMaxSize()) {
                    DashboardRoute(viewModel = viewModel)
                }
            }
        }
        ensureBlePermissions()
    }

    private fun ensureBlePermissions() {
        if (BlePermissions.anyMissing(this)) {
            permissionLauncher.launch(BlePermissions.required)
        }
    }
}
